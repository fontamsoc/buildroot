/*
htop - ZfsArcStats.c
(C) 2014 Hisham H. Muhammad
Released under the GNU GPLv2, see the COPYING file
in the source distribution for its full text.
*/

#include "Macros.h"

static int make_iso_compilers_happy ATTR_UNUSED;
